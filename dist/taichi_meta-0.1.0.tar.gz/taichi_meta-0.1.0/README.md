# taichi-meta
A Simple Taichi Addon that allows you to compile AND recompile kernels directly from strings.
